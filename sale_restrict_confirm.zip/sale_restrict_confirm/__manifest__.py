{
    'name': 'Restrict Quotation Confirm',
    'version': '1.0',
    'category': 'Sales',
    'summary': 'Prevent specific users or groups from confirming quotations',
    'depends': ['sale'],
    'data': [
    'security/groups.xml',
    ],
    'installable': True,
    'application': False,
}
