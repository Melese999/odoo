# -*- coding: utf-8 -*-
from . import models
from . import sale_order
from . import account_move
from . import crm_team
from . import res_partner
from . import product_product
from . import daily_counter
from . import sale_order_line
from . import account_move_line
from . import mrp_production
from . import stock_rule
from . import production_report_wizard
from . import models
from . import sketch_wizard
from . import stock_move
from . import procurement_group
# from. import mrp_production_report
# from. import procurement_group




