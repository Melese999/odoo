from . import models



# # Import the function from kpi_target.py
# from .models.kpi_target import _link_automation_triggers
#
# def _link_automation_triggers_hook(env):
#     """Hook function to be called after module installation."""
#     _link_automation_triggers(env)