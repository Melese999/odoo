from . import crm_lead_telemarketing
from . import telemarketing_call
from . import crm_phonecall_inherit
from . import telemarketing_status
from . import report_telemarketing
from . import report_telemarketing_dashboard
from . import telemarketing_call
