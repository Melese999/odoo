# crm_telemarketing/controllers/__init__.py

from .import telemarketing_dashboard