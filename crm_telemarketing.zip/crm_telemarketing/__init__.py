# crm_telemarketing/__init__.py

from . import models
from . import controllers